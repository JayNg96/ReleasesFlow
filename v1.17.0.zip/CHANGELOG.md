# [1.17.0](https://github.com/JayNg96/ReleasesFlow/compare/v1.16.0...v1.17.0) (2023-01-14)


### Features

* new feat ([d9b7429](https://github.com/JayNg96/ReleasesFlow/commit/d9b742941ad260aeb6f75aa6f66d0b8cb94ec069))



# [1.16.0](https://github.com/JayNg96/ReleasesFlow/compare/v1.15.0...v1.16.0) (2023-01-14)


### Features

* new feat ([d19d6fe](https://github.com/JayNg96/ReleasesFlow/commit/d19d6fecae405c4dd6e2a33b0764c9d932b3be97))
* new workflow patch ([664b6fd](https://github.com/JayNg96/ReleasesFlow/commit/664b6fd0975231966d41724b4043c03018a98695))



# [1.15.0](https://github.com/JayNg96/ReleasesFlow/compare/v1.14.0...v1.15.0) (2023-01-14)


### Features

* new feat ([7959861](https://github.com/JayNg96/ReleasesFlow/commit/79598610a316d8a10d6aaa35d310af6dc4d1940f))



# [1.14.0](https://github.com/JayNg96/ReleasesFlow/compare/v1.13.0...v1.14.0) (2023-01-14)


### Features

* new feat ([96bac85](https://github.com/JayNg96/ReleasesFlow/commit/96bac85d4dd42549c4e88a9c7e611d75070c9c03))
* new feat ([bfdf5b8](https://github.com/JayNg96/ReleasesFlow/commit/bfdf5b80989ddeadaa6006af2bb3d4a88ff7808d))
* new feat ([1080bf7](https://github.com/JayNg96/ReleasesFlow/commit/1080bf7bf7a24af509619d01a50d6d6e2e805f40))



# [1.13.0](https://github.com/JayNg96/ReleasesFlow/compare/v1.12.0...v1.13.0) (2023-01-12)


### Features

* new feature ([6b0b383](https://github.com/JayNg96/ReleasesFlow/commit/6b0b3837efac4fc2747b3cc4ffd6bd4ddbe7a301))



